# Planet_Animalia
Zoo management system
This is a project to keep track of the staff working in the zoo,the division they work in, the animals they take care of and the toursist. 
It also shows the total income obtained from tourist fare and donations.
Total expenditure is considered to be the salary of the staff.
From the total income and total expenditure the profit is calculated.
